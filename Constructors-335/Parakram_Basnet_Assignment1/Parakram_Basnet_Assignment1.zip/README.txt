Author: Parakram Basnet
Edited: 02/05/2019
Assignment 1 - The big five

Parts that were completed:

  Implementation of zero parameter constructor
  Implementation of copy constructor
  Implementation of copy assignment "="
  Implementation of move constructor
  Implementation of move assignment "="
  Implementation of destructor 
  Implementation of one parameter constructor
  Missing parts of "ReadPoints2" function
  Implementation of "size" function
  Implementation of overloaded [] operator
  Implementation of overloaded + operator
  Implementation of overloaded << operator

Parts that are incomplete: None

Current bugs in the program: None

Compilation Steps:

  To compile on terminal, type

    make clean
    make all

  To delete executables and object file type
    make clean

  To run program, type (will have to manually provide input during runtime)

    ./test_points2

  To run program and provide input from file with test cases, type

    ./test_points2 < test_input_file.txt